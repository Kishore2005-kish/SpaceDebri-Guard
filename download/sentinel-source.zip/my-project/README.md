# SENTINEL — Conjunction Awareness for Small-Sat Operators

> Hackathon problem PS-04.3 — Space-Debris Collision Risk Visualizer for Small Satellite Operators
>
> **"We make the first layer of conjunction awareness accessible to small satellite operators."**
>
> Not: "We predict collisions with AI."

A prototype decision-support platform that fetches **real CelesTrak GP/OMM orbital data**, propagates it with **real SGP4**, screens for close approaches over a 7-day horizon, computes an **explainable heuristic risk score** (NOT a probability of collision), simulates hypothetical maneuvers, and validates results against the public **CelesTrak SOCRATES** reference.

## Table of Contents

1. [Problem](#1-problem)
2. [Solution](#2-solution)
3. [Architecture](#3-architecture)
4. [Real data sources](#4-real-data-sources)
5. [SGP4](#5-sgp4)
6. [Conjunction detection](#6-conjunction-detection)
7. [Risk model](#7-risk-model)
8. [Confidence model](#8-confidence-model)
9. [Maneuver simulation](#9-maneuver-simulation)
10. [SOCRATES validation](#10-socrates-validation)
11. [CDM](#11-cdm)
12. [Installation](#12-installation)
13. [Environment variables](#13-environment-variables)
14. [Running locally](#14-running-locally)
15. [Refreshing real data](#15-refreshing-real-data)
16. [Running screening](#16-running-screening)
17. [Demo mode](#17-demo-mode)
18. [Testing](#18-testing)
19. [Limitations](#19-limitations)
20. [Safety disclaimer](#20-safety-disclaimer)
21. [Future work](#21-future-work)

---

## 1. Problem

Small-satellite operators (cubesats, nanosats, university payloads) typically lack the budget and infrastructure for commercial Space Situational Awareness (SSA) services. They need to answer:

> "Will my satellite have a potentially dangerous close approach in the next few days, why is it risky, how confident is the prediction, and what hypothetical maneuver timing could reduce the risk?"

Public data exists (CelesTrak GP/OMM, SOCRATES) but is hard to consume without specialist tooling.

## 2. Solution

SENTINEL is a single web application that:

- Fetches **real** orbital data from CelesTrak (not a fake catalog)
- Propagates with the **official SGP4 algorithm** (not a custom Keplerian)
- Computes an **explainable** heuristic risk score (0-100) with 5 weighted factors
- Computes a **separate** confidence score (0-100)
- **Never** displays a probability of collision (because public GP data lacks covariance — per NASA CARA)
- Simulates hypothetical maneuvers with **post-maneuver re-screening** against the full catalog
- Compares results against public SOCRATES data
- Produces auditable, reproducible analyses (every result includes data source, retrieval time, propagator version, snapshot ID, risk model version)
- Is explicitly labeled as a **prototype decision-support system**, not a flight-control system

## 3. Architecture

```
CelesTrak GP/OMM (real)
      ↓
Data Ingestion (z-ai-web-dev-sdk page_reader proxy; URL-encoded query workaround)
      ↓
Validation + Normalization
      ↓
SQLite (Prisma) — satellite + conjunction + snapshot tables
      ↓
SGP4 Propagation (sgp4 npm@1.0.10, WGS84, TEME frame)
      ↓
Conjunction Screening (coarse 60s + fine 1s + analytical TCA refinement)
      ↓
Risk + Confidence Engines (5-factor heuristic + 6-factor confidence)
      ↓
Visualization (canvas orbit viz + separation chart)
      ↓
Maneuver What-If Simulator (Radial / Along-track / Cross-track)
      ↓
Post-Maneuver Re-screen (against full catalog)
      ↓
SOCRATES Validation
      ↓
Reports + AI Explanation
```

See [docs/ARCHITECTURE.md](./docs/ARCHITECTURE.md) for the full Mermaid diagram and module layout.

## 4. Real data sources

| Source | Purpose | Format | URL |
| --- | --- | --- | --- |
| CelesTrak GP | Orbital elements | JSON / OMM / CSV / TLE | https://celestrak.org/NORAD/elements/ |
| CelesTrak GP format docs | Format reference | Web | https://celestrak.org/NORAD/documentation/gp-data-formats.php |
| CelesTrak SATCAT | Object metadata | CSV | https://celestrak.org/satcat/ |
| CelesTrak SOCRATES | Validation reference | CSV | https://celestrak.org/SOCRATES/ |
| SOCRATES format | CSV columns | Web | https://www.celestrak.org/SOCRATES/socrates-format.php |
| NASA CARA | Risk-assessment guidance | Web | https://www.nasa.gov/cara/step-2-close-approach-risk-assessment/ |
| NASA CARA software | Reference implementations | GitHub | https://github.com/nasa/CARA_Analysis_Tools |
| CCSDS CDM | Conjunction data message | Blue Book | https://ccsds.org/searchpubs/ (CCSDS 508.0-B-1) |

See [docs/DATA_SOURCES.md](./docs/DATA_SOURCES.md) for the full table with limitations.

## 5. SGP4

Production propagator: **`sgp4` npm package v1.0.10** — a NodeJS port of python-sgp4, which itself is based on the official "Revisiting Spacetrack Report #3" implementation by Vallado et al.

- Source: https://www.npmjs.com/package/sgp4
- Algorithm paper: https://celestrak.org/publications/AIAA/2006-6753/AIAA-2006-6753.pdf
- Gravity model: WGS84
- Output frame: TEME (True Equator Mean Equinox)

Implementation highlights:
- Calls `sgp4init()` directly with orbital elements, **bypassing the TLE parser**. This means 6+ digit NORAD catalog IDs work without truncation (per https://celestrak.org/NORAD/documentation/gp-data-formats.php).
- Satrec cache: orbital elements are hashed; the satrec object is built once and reused for every propagation call.
- Public API: `propagateSgp4(obj, t)`, `propagateRangeSgp4(obj, start, end, stepSec)`, `getStateVector(obj, t)`.

See [docs/SGP4.md](./docs/SGP4.md) for the full wrapper API and validation against ISS.

## 6. Conjunction detection

8-step pipeline:

1. **Candidate filtering** — altitude pre-filter (skip pairs where primary.apogee < secondary.perigee - 50km)
2. **Coarse propagation** — 60-second step over the 7-day horizon, 600km threshold (catches all sub-second high-velocity encounters)
3. **Distance evaluation** — `|r_primary - r_secondary|` at each sample
4. **Local-minimum detection** — find indices where `curr ≤ prev && curr ≤ next && curr < 600km`
5. **Fine search** — 1-second step in ±10-min window around each candidate
6. **Analytical TCA refinement** — `t* = t_fine - (r·v) / |v|²` (perpendicular projection — exact for constant v_rel)
7. **Relative state calculation** — `|r|`, `|v|`, RIC decomposition at TCA
8. **Event creation** — if min range < 5km threshold, store conjunction with full provenance

The analytical refinement (step 6) is critical for high-velocity encounters (e.g., 10 km/s rel vel → sub-100ms minimum window → 1-second sampling would miss it by orders of magnitude).

See [docs/CONJUNCTION_DETECTION.md](./docs/CONJUNCTION_DETECTION.md) and [docs/TCA_ALGORITHM.md](./docs/TCA_ALGORITHM.md).

## 7. Risk model

```
RiskScore = w1 * distanceRisk      (40%)
          + w2 * uncertaintyRisk    (20%)
          + w3 * velocityRisk       (15%)
          + w4 * geometryRisk       (15%)
          + w5 * freshnessRisk      (10%)
```

| Factor | Score 0→1 (worst case) | Rationale |
| --- | --- | --- |
| Miss distance | Sub-500m → 1.0; 5km → 0.0 (log curve) | Smaller miss = more dangerous |
| Data uncertainty | Covariance available → 0.4; debris w/o cov → 0.9 | Public GP lacks covariance |
| Relative velocity | 0.5 km/s → 0; 15 km/s → 1.0 | Higher rel vel = shorter encounter window + higher impact energy |
| Encounter geometry | 0 = pure cross-track; 1 = along/radial | Head-on encounters are more dangerous |
| Data freshness | 0h → 0; 72h → 1.0 | Stale elements = larger uncertainty |

Risk levels: 0-24 LOW, 25-49 MODERATE, 50-74 HIGH, 75-100 CRITICAL.

> ⚠ This is a **prototype heuristic** and is NOT equivalent to professional probability-of-collision (Pc) analysis. Professional Pc requires covariance data not present in the public GP dataset. Per NASA CARA.

See [docs/RISK_MODEL.md](./docs/RISK_MODEL.md) for the full formula and a sample calculation.

## 8. Confidence model

Separate 0-100 score reflecting **trust in the inputs** (not the risk itself):

| Contributor | Penalty |
| --- | --- |
| Data age > 48h | -25 |
| Data age > 24h | -15 |
| Data age > 12h | -8 |
| Data age > 6h | -4 |
| Source: CelesTrak | -5 |
| Source: DEMO | -30 |
| Format: TLE | -5 |
| Covariance unavailable | -15 |
| Propagation horizon > 5 days | -12 |
| Missing metadata | -8 |

Levels: ≥75 HIGH, ≥50 MEDIUM, <50 LOW.

See [docs/CONFIDENCE_MODEL.md](./docs/CONFIDENCE_MODEL.md).

## 9. Maneuver simulation

What-if simulator (NOT an autonomous planner). For each scenario:

1. Take the maneuver time (hours before TCA)
2. SGP4-propagate the primary state forward to the burn time
3. Apply an impulsive ΔV in the requested RIC-frame direction (Radial / Along-track / Cross-track)
4. Convert the post-burn Cartesian state back to orbital elements via `cartesianToClassical`
5. SGP4-propagate the new primary and the original secondary to TCA and beyond
6. Re-screen the post-burn primary against the original secondary AND against the rest of the catalog (the **secondary conjunction check** — a maneuver that fixes one event may create another)
7. Compute new miss distance, new risk score, ΔV used, semi-major axis change

Default scenarios: burns at 72/48/36/24/12/6 hours before TCA, ~0.05-0.12 m/s along-track.

> ⚠ "Simulation only — not a flight command. Operational decisions require authoritative orbital data and qualified flight-dynamics analysis."

The maneuver does NOT modify the stored real catalog object — it produces a temporary simulated state with `source = 'SENTINEL-SIMULATED'`.

See [docs/MANEUVER_SIMULATION.md](./docs/MANEUVER_SIMULATION.md).

## 10. SOCRATES validation

CelesTrak SOCRATES (Satellite Orbital Conjunction Reports Assessing Threatening Encounters in Space) is an **independent public reference** — NOT ground truth.

Format: https://www.celestrak.org/SOCRATES/socrates-format.php (CSV with columns: Satellite A Catalog Number, Satellite A Name, Satellite B Catalog Number, Satellite B Name, TCA, Min Range, Relative Velocity).

SENTINEL fetches SOCRATES via `GET /api/socrates` and compares a specific conjunction event against matching SOCRATES records via `POST /api/socrates` with `{conjunctionId}`.

Output: detected (boolean), TCA error (minutes), range error (km), reference TCA / range / rel vel.

See [docs/SOCRATES_VALIDATION.md](./docs/SOCRATES_VALIDATION.md).

## 11. CDM

CCSDS Conjunction Data Message (CCSDS 508.0-B-1). SENTINEL supports:

- `POST /api/cdm/import` — parse KVN (`KEY = VALUE`) text
- `GET /api/cdm/{id}/export` — generate a CDM from a conjunction

Fields we generate: `OBJECT1/2 OBJECT_ID`, `OBJECT1/2 NAME`, `TCA`, `MIN_RNG`, `REL_VEL`, `RISK_SCORE` (with explicit note "heuristic, NOT Pc"), `CONFIDENCE`, `COVARIANCE = UNAVAILABLE`, `SCREEN_THRESHOLD`, `PROPAGATOR`, `DATA_SOURCE`, `SNAPSHOT_ID`.

Fields unavailable from public GP data: covariance matrix, object physical properties, tracking accuracy. SENTINEL displays these as `UNAVAILABLE` rather than fabricating them.

See [docs/CDM.md](./docs/CDM.md).

## 12. Installation

Prerequisites:
- [Bun](https://bun.sh/) (or Node 18+)
- (Optional) PostgreSQL 14+ for production; SQLite is used by default for the prototype

```bash
git clone <repo>
cd sentinel
bun install
```

## 13. Environment variables

Create `.env` in the project root:

```bash
# SQLite (default — for prototype)
DATABASE_URL="file:/home/z/my-project/db/custom.db"

# PostgreSQL (production)
# DATABASE_URL="postgresql://user:pass@localhost:5432/sentinel?schema=public"

# Optional: if you want to use the LLM-powered AI assistant
ZAI_API_KEY=...
```

## 14. Running locally

```bash
bun run db:push      # create tables
bun run dev           # start Next.js dev server on :3000
```

Open http://localhost:3000/ in your browser.

The app starts in **DEMO mode** (synthetic dataset, clearly labeled yellow). To switch to **LIVE mode**, click the green "FETCH REAL CELESTRAK DATA" button on the dashboard.

## 15. Refreshing real data

```bash
# Via the API:
curl -X POST http://localhost:3000/api/orbits/refresh \
  -H "Content-Type: application/json" \
  -d '{"groups":["stations"]}'

# Or click "FETCH REAL CELESTRAK DATA" in the dashboard UI.
```

The refresh endpoint:
1. Fetches real GP/OMM JSON from `https://celestrak.org/NORAD/elements/gp.php?GROUP=stations&FORMAT=JSON`
2. Validates required fields (OBJECT_NAME, EPOCH, MEAN_MOTION, NORAD_CAT_ID, etc.)
3. Normalizes (UPPER_SNAKE_CASE → camelCase, mean motion → semi-major axis, etc.)
4. Upserts into the Satellite table (catalog IDs stored as String, no truncation)
5. Records a DataRefreshLog entry (source, URL, status, recordsParsed, recordsRejected, parseErrors, durationMs)
6. Creates a CatalogSnapshot (`CT-YYYYMMDDHHMM`) so analyses are reproducible
7. Returns: objectsImported, objectsUpdated, parseErrors, snapshotId, status (OK / FETCH_ERROR / PARSE_ERROR / PARTIAL)

## 16. Running screening

```bash
# Screen all protected satellites against the entire catalog over 7 days:
curl -X POST http://localhost:3000/api/screen \
  -H "Content-Type: application/json" \
  -d '{}'
```

Or click the "RE-SCREEN" button in the dashboard.

For each primary, every other catalog object is screened (with altitude pre-filtering for performance). Conjunctions below 5 km miss distance are stored with full provenance (analysisId, dataSource, retrievedAt, primaryEpoch, secondaryEpoch, propagator, propagatorFrame, snapshotId, riskModelVersion, riskWeights).

## 17. Demo mode

The deterministic **DEMO scenario** is kept for offline demonstrations. It contains 3 synthetic protected satellites (MySat-01/02/03) and 21 synthetic catalog objects, including a CRITICAL conjunction at ~96m miss distance.

All DEMO objects are clearly labeled:
- Source: `SENTINEL-DEMO`
- Operational status: `SYNTHETIC-DEMO-OBJECT`
- UI badge: yellow `●DEMO` next to every DEMO conjunction

Click "START DEMO" in the top-right corner for a 5-minute automated showcase.

## 18. Testing

```bash
# Test SGP4 propagation with real ISS data:
bun run scripts/test-sgp4.ts

# Test end-to-end real-data flow:
bun run scripts/test-real-data.ts

# Debug a specific conjunction:
bun run scripts/debug-screen.ts

# Lint:
bun run lint
```

See [docs/TESTING.md](./docs/TESTING.md) for the full test plan.

## 19. Limitations

SENTINEL is explicitly a **prototype decision-support system, not authoritative collision avoidance**:

- Public GP/TLE data is **not authoritative**.
- The heuristic risk score is **not** a probability of collision.
- Covariance is **unavailable** in this prototype.
- Maneuver simulations are **hypothetical**.
- SGP4 propagation has accuracy limits over multi-day horizons.
- This tool does **not** replace professional SSA services.
- No autonomous spacecraft commands are produced.
- SOCRATES is an independent reference, not ground truth.

See [docs/LIMITATIONS.md](./docs/LIMITATIONS.md) for the full list.

## 20. Safety disclaimer

Every maneuver result displays:

> "Simulation only — not a flight command. Operational decisions require authoritative orbital data and qualified flight-dynamics analysis."

Every risk score displays:

> "Prototype heuristic risk score, not official collision probability. Professional collision probability cannot be reliably calculated from the available data because covariance is unavailable."

The system follows NASA CARA guidance: https://www.nasa.gov/cara/step-2-close-approach-risk-assessment/

## 21. Future work

P1:
- Real 3D globe via CesiumJS (current is a canvas 2D top-down projection)
- Real covariance ingestion from CDMs (if available from operators)
- Multi-satellite maneuver planning (current is single-event)

P2:
- Constellation / fleet view
- Conjunction heatmap
- Risk trend over successive data updates
- "What changed?" diff between orbital updates
- Launch-orbit screening
- Re-entry / decay indicator
- Daily AI-generated mission briefing
- Space-weather data integration
- Operator-side tracking data ingestion

## Documentation

Full documentation is in [`docs/`](./docs/) — start with [docs/README.md](./docs/README.md) for the index.

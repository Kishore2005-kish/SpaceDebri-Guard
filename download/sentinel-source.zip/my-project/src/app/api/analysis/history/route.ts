import { NextResponse } from 'next/server';
import { listAnalysisRuns } from '@/lib/simulation/analysis';

export const dynamic = 'force-dynamic';

// GET /api/analysis/history
// Returns past analysis runs for the history view.
export async function GET() {
  const runs = await listAnalysisRuns(50);
  return NextResponse.json({
    runs: runs.map(r => ({
      id: r.id,
      status: r.status,
      progress: r.progress,
      startedAt: r.startedAt.toISOString(),
      completedAt: r.completedAt?.toISOString() ?? null,
      preset: r.preset,
      engineUsed: r.engineUsed,
      conjunctionsFound: r.conjunctionsFound,
      candidatesFiltered: r.candidatesFiltered,
      progressMessage: r.progressMessage,
    })),
  });
}

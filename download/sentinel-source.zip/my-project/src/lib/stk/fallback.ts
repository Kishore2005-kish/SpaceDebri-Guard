// SGP4-based fallback for the STK interface.
//
// When STK is not installed (the common case in this sandbox), SENTINEL
// falls back to its own SGP4-based simulation. This fallback module
// implements the SAME interface as `service.ts` so the rest of the
// application (UI, API routes, simulation orchestrator) is unchanged.
//
// The fallback uses:
//   - The `sgp4` npm package for orbital propagation (same as production)
//   - The existing conjunction screening engine for TCA / min range
//   - Generated trajectory samples for the 3D visualization
//
// The result is labeled "SENTINEL SGP4 (fallback)" — never "STK".
// Per the user's instructions: "Never pretend SENTINEL SGP4 is STK."

import { OrbitalObject } from '@/lib/data/celestrak/types';
import { propagateSgp4, SGP4_VERSION, SGP4_FRAME } from '@/lib/orbital/sgp4';
import { screen, DEFAULT_SCREENING_HORIZON_DAYS, DEFAULT_SCREENING_THRESHOLD_KM } from '@/lib/orbital/conjunction';
import { relativeMotion } from '@/lib/orbital/propagator';
import { StkScenarioConfig, StkConjunctionResult, TrajectoryPoint } from './types';
import { v4 as uuidv4 } from 'uuid';

/**
 * Run the conjunction analysis using SGP4 (fallback when STK is unavailable).
 * Returns a result with the SAME shape as `StkConjunctionResult` so the UI
 * can render it the same way regardless of which engine was used.
 *
 * The result is explicitly labeled "SENTINEL SGP4 (fallback)" in the
 * `engine` field, with `fallbackReason` explaining why STK wasn't used.
 */
export async function runSgp4Fallback(
  config: StkScenarioConfig,
  fallbackReason: string,
): Promise<StkConjunctionResult> {
  const primaryObj = toOrbitalObject(config.primary);
  const secondaryObjs = config.secondaries.map(toOrbitalObject);

  const start = new Date(config.analysisStart);
  const end = new Date(config.analysisEnd);

  // Screen the primary against each secondary, find the closest conjunction
  let bestResult: ReturnType<typeof screen> = null;
  let bestSecondary: OrbitalObject | null = null;
  for (const sec of secondaryObjs) {
    const conj = screen(primaryObj, sec, start, end, config.thresholdKm);
    if (conj && (!bestResult || conj.minRange < bestResult.minRange)) {
      bestResult = conj;
      bestSecondary = sec;
    }
  }

  if (!bestResult || !bestSecondary) {
    throw new Error('SGP4 fallback: no conjunction found within the threshold');
  }

  // Generate trajectories for visualization (±1 hour around TCA, 60s step)
  const tcaMs = bestResult.tca.getTime();
  const trajStart = new Date(tcaMs - 3600 * 1000);
  const trajEnd = new Date(tcaMs + 3600 * 1000);
  const primaryTrajectory = generateTrajectory(primaryObj, trajStart, trajEnd, config.trajectoryStepSec);
  const secondaryTrajectory = generateTrajectory(bestSecondary, trajStart, trajEnd, config.trajectoryStepSec);

  // Build separation series from the trajectories
  const separationSeries: { t: string; range: number }[] = [];
  for (let i = 0; i < primaryTrajectory.length && i < secondaryTrajectory.length; i++) {
    const p = primaryTrajectory[i];
    const s = secondaryTrajectory[i];
    const rel = relativeMotion(p as any, s as any);
    separationSeries.push({ t: p.t, range: rel.range });
  }

  return {
    engine: 'SENTINEL SGP4 (fallback)',
    engineVersion: SGP4_VERSION,
    primary: { catalogId: config.primary.catalogId, name: config.primary.name },
    secondary: { catalogId: bestSecondary.catalogId, name: bestSecondary.name, objectType: bestSecondary.objectType },
    tca: bestResult.tca.toISOString(),
    minimumRangeKm: bestResult.minRange,
    minimumSeparationKm: bestResult.minRange,
    relativeVelocityKmPerSec: bestResult.relVelocity,
    thresholdKm: config.thresholdKm,
    analysisStart: config.analysisStart,
    analysisEnd: config.analysisEnd,
    primaryTrajectory,
    secondaryTrajectory,
    separationSeries,
    covarianceAvailable: false,
    collisionProbabilityAvailable: false,
    fallbackReason,
    stkVersion: null,
    stkScenarioId: `SENTINEL-${uuidv4().slice(0, 8)}`,
    stkAnalysisId: uuidv4(),
    stkResultTimestamp: new Date().toISOString(),
    stkRawReportHash: hashJson({ primary: config.primary, secondary: bestSecondary, tca: bestResult.tca }),
  };
}

/** Generate a trajectory (state vector at each time step) using SGP4. */
function generateTrajectory(obj: OrbitalObject, start: Date, end: Date, stepSec: number): TrajectoryPoint[] {
  const points: TrajectoryPoint[] = [];
  for (let ms = start.getTime(); ms <= end.getTime(); ms += stepSec * 1000) {
    try {
      const s = propagateSgp4(obj, new Date(ms));
      points.push({
        t: s.t.toISOString(),
        x: s.x, y: s.y, z: s.z,
        vx: s.vx, vy: s.vy, vz: s.vz,
      });
    } catch {
      // skip propagation failures (e.g., decayed object)
    }
  }
  return points;
}

/** Convert a StkSecondaryCandidate to an OrbitalObject (for SGP4 propagation). */
function toOrbitalObject(c: StkScenarioConfig['primary']): OrbitalObject {
  return {
    catalogId: c.catalogId,
    name: c.name,
    internationalDesignator: undefined,
    objectType: c.objectType as any,
    operationalStatus: undefined,
    epoch: c.epoch,
    meanMotion: c.meanMotion,
    eccentricity: c.eccentricity,
    inclination: c.inclination,
    raOfAscendingNode: c.raOfAscendingNode,
    argumentOfPerigee: c.argumentOfPerigee,
    meanAnomaly: c.meanAnomaly,
    bstar: c.bstar,
    revAtEpoch: 0,
    semiMajorAxisKm: undefined,
    perigeeKm: undefined,
    apogeeKm: undefined,
    orbitalPeriodMin: undefined,
    source: c.source,
    retrievedAt: new Date().toISOString(),
    format: 'OMM',
    rawDataHash: '',
  };
}

/** Stable hash of a JSON-serializable object. */
function hashJson(obj: any): string {
  const json = JSON.stringify(obj);
  let h = 0x811c9dc5;
  for (let i = 0; i < json.length; i++) {
    h ^= json.charCodeAt(i);
    h = (h * 0x01000193) >>> 0;
  }
  return h.toString(16).padStart(8, '0').repeat(2).slice(0, 16);
}

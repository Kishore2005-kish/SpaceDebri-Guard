'use client';
import { useUI, ViewKey } from '@/lib/store';
import { Globe, Satellite, Zap, Activity, History, FileText } from 'lucide-react';
import { cn } from '@/lib/utils';

const ITEMS: { key: ViewKey; label: string; icon: any }[] = [
  { key: 'overview', label: 'Overview', icon: Globe },
  { key: 'satellites', label: 'Satellites', icon: Satellite },
  { key: 'analyze', label: 'Analyze', icon: Zap },
  { key: 'simulation', label: 'Simulation', icon: Activity },
  { key: 'history', label: 'History', icon: History },
  { key: 'docs', label: 'Documentation', icon: FileText },
];

export function Sidebar() {
  const { view, setView } = useUI();
  return (
    <nav className="w-48 shrink-0 border-r border-border bg-card/50 flex flex-col">
      <ul className="py-2">
        {ITEMS.map((item) => {
          const Icon = item.icon;
          const active = view === item.key;
          return (
            <li key={item.key}>
              <button
                onClick={() => setView(item.key)}
                className={cn(
                  'w-full flex items-center gap-2.5 px-3 py-2.5 text-[12px] font-mono tracking-wide transition-colors',
                  active
                    ? 'bg-primary/15 text-primary border-l-2 border-primary'
                    : 'text-muted-foreground hover:bg-muted/40 hover:text-foreground border-l-2 border-transparent'
                )}
              >
                <Icon className="h-4 w-4" />
                <span>{item.label}</span>
              </button>
            </li>
          );
        })}
      </ul>
      <div className="mt-auto p-3 border-t border-border">
        <div className="text-[9px] font-mono text-muted-foreground leading-relaxed space-y-1">
          <div className="flex justify-between"><span>Source</span><span className="text-primary">CelesTrak</span></div>
          <div className="flex justify-between"><span>Propagator</span><span>SGP4</span></div>
          <div className="flex justify-between"><span>Screen</span><span>7d / 5km</span></div>
        </div>
      </div>
    </nav>
  );
}

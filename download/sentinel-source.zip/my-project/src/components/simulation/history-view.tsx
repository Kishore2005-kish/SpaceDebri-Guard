'use client';
import { useEffect, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { History, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AnalysisRun {
  id: string;
  status: string;
  progress: number;
  startedAt: string;
  completedAt: string | null;
  preset: string | null;
  engineUsed: string | null;
  conjunctionsFound: number;
  candidatesFiltered: number;
  progressMessage: string | null;
}

export function HistoryView() {
  const [runs, setRuns] = useState<AnalysisRun[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/analysis/history').then(r => r.json()).then(j => {
      setRuns(j.runs || []);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return <div className="p-6 text-sm font-mono text-muted-foreground">Loading history…</div>;
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-mono font-bold mb-4">Analysis History</h1>
      {runs.length === 0 ? (
        <Card className="p-8 text-center">
          <p className="text-sm text-muted-foreground font-mono">No analyses have been run yet.</p>
        </Card>
      ) : (
        <div className="space-y-2">
          {runs.map((r) => (
            <Card key={r.id} className="p-3">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  {r.status === 'COMPLETE' ? (
                    <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
                  ) : r.status === 'FAILED' ? (
                    <AlertCircle className="h-4 w-4 text-red-500 shrink-0" />
                  ) : (
                    <Loader2 className="h-4 w-4 text-amber-500 shrink-0 animate-spin" />
                  )}
                  <div className="min-w-0">
                    <div className="font-mono text-xs font-bold">
                      {r.preset ?? 'CUSTOM'} · {r.engineUsed ?? 'SGP4'}
                    </div>
                    <div className="font-mono text-[10px] text-muted-foreground mt-0.5">
                      {new Date(r.startedAt).toISOString().slice(0, 19)}Z ·
                      {' '}{r.conjunctionsFound} conjunctions ·
                      {' '}{r.candidatesFiltered} pairs screened
                    </div>
                    {r.progressMessage && (
                      <div className="font-mono text-[9px] text-muted-foreground truncate mt-0.5">
                        {r.progressMessage}
                      </div>
                    )}
                  </div>
                </div>
                <div className={cn(
                  'font-mono text-[10px] font-bold shrink-0',
                  r.status === 'COMPLETE' ? 'text-emerald-500' :
                  r.status === 'FAILED' ? 'text-red-500' : 'text-amber-500'
                )}>
                  {r.status}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

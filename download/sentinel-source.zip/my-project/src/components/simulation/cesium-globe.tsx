'use client';
import { useEffect, useRef, useState } from 'react';
import * as Cesium from 'cesium';
import 'cesium/Build/Cesium/Widgets/widgets.css';

interface TrajectoryPoint {
  t: string; x: number; y: number; z: number;
  vx: number; vy: number; vz: number;
}

interface Props {
  primaryTrajectory: TrajectoryPoint[];
  secondaryTrajectory: TrajectoryPoint[];
  primaryName: string;
  secondaryName: string;
  tca: string;
  minimumRangeKm: number;
  onTimeChange?: (currentTime: Date) => void;
}

/**
 * Cesium 3D Globe simulation component.
 * Uses the official CesiumJS library to render a real 3D Earth globe.
 * No Ion token required — uses free ArcGIS imagery and ellipsoid terrain.
 */
export function CesiumGlobe({
  primaryTrajectory,
  secondaryTrajectory,
  primaryName,
  secondaryName,
  tca,
  minimumRangeKm,
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const viewerRef = useRef<Cesium.Viewer | null>(null);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [cameraMode, setCameraMode] = useState<'ORBIT' | 'ENCOUNTER' | 'FOLLOW_PRIMARY' | 'FOLLOW_SECONDARY'>('ORBIT');
  const [currentTime, setCurrentTime] = useState('--:--:--');
  const [tcaCountdown, setTcaCountdown] = useState('--');
  const [ready, setReady] = useState(false);

  // Initialize Cesium Viewer (client-only)
  useEffect(() => {
    if (!containerRef.current) return;
    (window as any).CESIUM_BASE_URL = '/cesium';
    const container = containerRef.current;

    // Delay Cesium init to avoid React DOM conflicts
    const initTimer = setTimeout(() => {
      try {
        const viewer = new Cesium.Viewer(container, {
          animation: false,
          timeline: false,
          baseLayerPicker: false,
          fullscreenButton: false,
          geocoder: false,
          homeButton: false,
          sceneModePicker: false,
          navigationHelpButton: false,
          selectionIndicator: false,
          infoBox: false,
          creditContainer: document.createElement('div'),
          baseLayer: false,
        });
        viewerRef.current = viewer;

        // Add free ArcGIS imagery
        viewer.imageryLayers.addImageryProvider(
          new Cesium.UrlTemplateImageryProvider({
            url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
            maximumLevel: 18,
          })
        );

        viewer.scene.globe.enableLighting = true;
        setReady(true);
      } catch (e) {
        console.error('Cesium init failed:', e);
      }
    }, 100);

    return () => {
      clearTimeout(initTimer);
      if (viewerRef.current) {
        try { viewerRef.current.destroy(); } catch {}
        viewerRef.current = null;
      }
    };
  }, []);

  function toCartesian3(point: TrajectoryPoint): Cesium.Cartesian3 {
    return new Cesium.Cartesian3(point.x * 1000, point.y * 1000, point.z * 1000);
  }

  // Camera helpers
  function flyToEncounter() {
    if (!viewerRef.current || primaryTrajectory.length === 0) return;
    const tcaTime = new Date(tca);
    let nearestIdx = 0;
    let nearestDiff = Infinity;
    for (let i = 0; i < primaryTrajectory.length; i++) {
      const diff = Math.abs(new Date(primaryTrajectory[i].t).getTime() - tcaTime.getTime());
      if (diff < nearestDiff) { nearestDiff = diff; nearestIdx = i; }
    }
    const pos = toCartesian3(primaryTrajectory[nearestIdx]);
    viewerRef.current.camera.flyTo({
      destination: Cesium.Cartesian3.add(pos, new Cesium.Cartesian3(100000, 100000, 100000), new Cesium.Cartesian3()),
      orientation: { heading: 0, pitch: Cesium.Math.toRadians(-45), roll: 0 },
      duration: 2,
    });
  }

  function resetCamera() {
    if (!viewerRef.current) return;
    viewerRef.current.camera.flyTo({
      destination: Cesium.Cartesian3.fromDegrees(0, 0, 20000000),
      duration: 2,
    });
    setCameraMode('ORBIT');
  }

  function jumpToTca() {
    if (!viewerRef.current) return;
    const tcaJulian = Cesium.JulianDate.fromIso8601(tca);
    viewerRef.current.clock.currentTime = tcaJulian.clone();
    setPlaying(false);
    flyToEncounter();
  }

  function jumpNow() {
    if (!viewerRef.current) return;
    viewerRef.current.clock.currentTime = Cesium.JulianDate.now();
  }

  // Add/update entities when trajectory data changes
  useEffect(() => {
    if (!viewerRef.current || !ready) return;
    if (primaryTrajectory.length === 0 || secondaryTrajectory.length === 0) return;

    const viewer = viewerRef.current;
    viewer.entities.removeAll();

    const startJulian = Cesium.JulianDate.fromIso8601(primaryTrajectory[0].t);
    const endJulian = Cesium.JulianDate.fromIso8601(primaryTrajectory[primaryTrajectory.length - 1].t);

    viewer.clock.startTime = startJulian.clone();
    viewer.clock.stopTime = endJulian.clone();
    viewer.clock.currentTime = startJulian.clone();
    viewer.clock.clockRange = Cesium.ClockRange.LOOP_STOP;

    // Build SampledPositionProperty for primary
    const primaryPosition = new Cesium.SampledPositionProperty();
    for (const p of primaryTrajectory) {
      primaryPosition.addSample(Cesium.JulianDate.fromIso8601(p.t), toCartesian3(p));
    }

    // Build SampledPositionProperty for secondary
    const secondaryPosition = new Cesium.SampledPositionProperty();
    for (const p of secondaryTrajectory) {
      secondaryPosition.addSample(Cesium.JulianDate.fromIso8601(p.t), toCartesian3(p));
    }

    // Primary satellite
    viewer.entities.add({
      name: primaryName,
      position: primaryPosition,
      point: { pixelSize: 8, color: Cesium.Color.fromCssColorString('#5ee695'), outlineColor: Cesium.Color.WHITE, outlineWidth: 2 },
      label: {
        text: primaryName, font: '12px monospace',
        fillColor: Cesium.Color.fromCssColorString('#5ee695'),
        outlineColor: Cesium.Color.BLACK, outlineWidth: 2,
        style: Cesium.LabelStyle.FILL_AND_OUTLINE,
        pixelOffset: new Cesium.Cartesian2(15, -10),
      },
    });

    // Secondary object
    viewer.entities.add({
      name: secondaryName,
      position: secondaryPosition,
      point: { pixelSize: 6, color: Cesium.Color.fromCssColorString('#ffb450'), outlineColor: Cesium.Color.WHITE, outlineWidth: 2 },
      label: {
        text: secondaryName, font: '12px monospace',
        fillColor: Cesium.Color.fromCssColorString('#ffb450'),
        outlineColor: Cesium.Color.BLACK, outlineWidth: 2,
        style: Cesium.LabelStyle.FILL_AND_OUTLINE,
        pixelOffset: new Cesium.Cartesian2(15, 15),
      },
    });

    // Primary orbit track
    viewer.entities.add({
      name: `${primaryName} Orbit`,
      polyline: {
        positions: primaryTrajectory.map(p => toCartesian3(p)),
        width: 1.5,
        material: Cesium.Color.fromCssColorString('rgba(94, 230, 149, 0.5)'),
      },
    });

    // Secondary orbit track
    viewer.entities.add({
      name: `${secondaryName} Orbit`,
      polyline: {
        positions: secondaryTrajectory.map(p => toCartesian3(p)),
        width: 1.5,
        material: Cesium.Color.fromCssColorString('rgba(255, 180, 80, 0.5)'),
      },
    });

    // TCA — find nearest sample to actual TCA timestamp (not array midpoint)
    const tcaTime = new Date(tca);
    const tcaTimeMs = tcaTime.getTime();

    let nearestPIdx = 0, nearestPDiff = Infinity;
    for (let i = 0; i < primaryTrajectory.length; i++) {
      const d = Math.abs(new Date(primaryTrajectory[i].t).getTime() - tcaTimeMs);
      if (d < nearestPDiff) { nearestPDiff = d; nearestPIdx = i; }
    }
    let nearestSIdx = 0, nearestSDiff = Infinity;
    for (let i = 0; i < secondaryTrajectory.length; i++) {
      const d = Math.abs(new Date(secondaryTrajectory[i].t).getTime() - tcaTimeMs);
      if (d < nearestSDiff) { nearestSDiff = d; nearestSIdx = i; }
    }

    // Minimum separation line
    if (primaryTrajectory[nearestPIdx] && secondaryTrajectory[nearestSIdx]) {
      const pPos = toCartesian3(primaryTrajectory[nearestPIdx]);
      const sPos = toCartesian3(secondaryTrajectory[nearestSIdx]);
      viewer.entities.add({
        name: 'Minimum Separation',
        polyline: {
          positions: [pPos, sPos],
          width: 2,
          material: new Cesium.PolylineGlowMaterialProperty({
            glowPower: 0.2,
            color: Cesium.Color.fromCssColorString('#ff5050'),
          }),
        },
        label: {
          text: minimumRangeKm < 1 ? `${(minimumRangeKm * 1000).toFixed(0)} m` : `${minimumRangeKm.toFixed(3)} km`,
          font: 'bold 14px monospace',
          fillColor: Cesium.Color.fromCssColorString('#ff5050'),
          outlineColor: Cesium.Color.BLACK, outlineWidth: 2,
          style: Cesium.LabelStyle.FILL_AND_OUTLINE,
          pixelOffset: new Cesium.Cartesian2(20, -20),
        },
      });

      // TCA marker
      const mid = Cesium.Cartesian3.lerp(pPos, sPos, 0.5, new Cesium.Cartesian3());
      if (mid) {
        viewer.entities.add({
          name: 'TCA', position: mid,
          point: { pixelSize: 10, color: Cesium.Color.fromCssColorString('#ff5050').withAlpha(0.5), outlineColor: Cesium.Color.fromCssColorString('#ff5050'), outlineWidth: 2 },
          label: {
            text: 'TCA', font: 'bold 12px monospace',
            fillColor: Cesium.Color.fromCssColorString('#ff5050'),
            outlineColor: Cesium.Color.BLACK, outlineWidth: 2,
            style: Cesium.LabelStyle.FILL_AND_OUTLINE,
            pixelOffset: new Cesium.Cartesian2(20, -25),
          },
        });
      }
    }

    // Fly to full Earth view
    viewer.camera.flyTo({
      destination: Cesium.Cartesian3.fromDegrees(0, 0, 20000000),
      duration: 2,
    });

    // Clock tick callback
    const tickListener = (clock: Cesium.Clock) => {
      const date = Cesium.JulianDate.toDate(clock.currentTime);
      setCurrentTime(date.toISOString().slice(11, 19) + 'Z');

      const diff = tcaTime.getTime() - date.getTime();
      if (diff > 0) {
        const h = Math.floor(diff / 3600000);
        const m = Math.floor((diff % 3600000) / 60000);
        setTcaCountdown(`T-${h}h ${m}m`);
      } else {
        const ad = Math.abs(diff);
        setTcaCountdown(`T+${Math.floor(ad / 3600000)}h ${Math.floor((ad % 3600000) / 60000)}m`);
      }

      if (cameraMode === 'FOLLOW_PRIMARY') {
        const pos = primaryPosition.getValue(clock.currentTime);
        if (pos) viewer.camera.lookAt(pos, new Cesium.HeadingPitchRange(0, Cesium.Math.toRadians(-45), 500000));
      } else if (cameraMode === 'FOLLOW_SECONDARY') {
        const pos = secondaryPosition.getValue(clock.currentTime);
        if (pos) viewer.camera.lookAt(pos, new Cesium.HeadingPitchRange(0, Cesium.Math.toRadians(-45), 500000));
      }

      if (playing && Math.abs(diff) < 2000 && speed > 0) {
        setPlaying(false);
        flyToEncounter();
      }
    };
    viewer.clock.onTick.addEventListener(tickListener);

    return () => {
      viewer.clock.onTick.removeEventListener(tickListener);
    };
  }, [primaryTrajectory, secondaryTrajectory, tca, minimumRangeKm, ready, cameraMode, playing, speed]);

  useEffect(() => {
    if (!viewerRef.current) return;
    viewerRef.current.clock.shouldRun = playing;
  }, [playing]);

  useEffect(() => {
    if (!viewerRef.current) return;
    viewerRef.current.clock.multiplier = speed;
  }, [speed]);

  const SPEEDS = [0.25, 1, 10, 100, 1000];

  return (
    <div className="relative w-full h-full bg-black">
      <div ref={containerRef} className="w-full h-full" />

      {ready && (
        <div className="absolute top-3 left-3 z-10 bg-black/70 backdrop-blur rounded px-3 py-2 font-mono text-[10px] space-y-0.5">
          <div className="text-emerald-400">SIM TIME: {currentTime}</div>
          <div className="text-red-400">TCA: {tca ? new Date(tca).toISOString().slice(11, 19) + 'Z' : '--'}</div>
          <div className={tcaCountdown.startsWith('T-') ? 'text-emerald-400' : 'text-red-400'}>COUNTDOWN: {tcaCountdown}</div>
          <div className="text-amber-400 mt-1">ENGINE: SGP4</div>
        </div>
      )}

      {ready && (
        <div className="absolute top-3 right-3 z-10 flex flex-col gap-1">
          {(['ORBIT', 'ENCOUNTER', 'FOLLOW_PRIMARY', 'FOLLOW_SECONDARY'] as const).map(mode => (
            <button key={mode} onClick={() => { setCameraMode(mode); if (mode === 'ORBIT') resetCamera(); if (mode === 'ENCOUNTER') flyToEncounter(); }}
              className={`px-2 py-1 text-[9px] font-mono rounded border transition-colors ${cameraMode === mode ? 'bg-primary text-primary-foreground border-primary' : 'bg-black/70 text-muted-foreground border-border hover:bg-muted/40'}`}>
              {mode.replace('_', ' ')}
            </button>
          ))}
          <button onClick={resetCamera} className="px-2 py-1 text-[9px] font-mono rounded border border-border bg-black/70 text-muted-foreground hover:bg-muted/40">RESET</button>
        </div>
      )}

      {ready && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-10 flex items-center gap-2 bg-black/70 backdrop-blur rounded px-3 py-2">
          <button onClick={() => { setPlaying(false); jumpNow(); }} className="text-[10px] font-mono text-muted-foreground hover:text-foreground">NOW</button>
          <button onClick={jumpToTca} className="px-3 py-1 text-[10px] font-mono font-bold rounded border border-red-500/40 bg-red-500/10 text-red-400">JUMP TO TCA</button>
          <button onClick={() => setPlaying(!playing)} className="px-3 py-1 text-[11px] font-mono rounded border border-border hover:bg-muted/40">
            {playing ? '⏸ PAUSE' : '▶ PLAY'}
          </button>
          <div className="flex items-center gap-1 ml-2">
            {SPEEDS.map(s => (
              <button key={s} onClick={() => setSpeed(s)}
                className={`px-1.5 py-0.5 text-[9px] font-mono rounded ${speed === s ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted/40'}`}>{s}x</button>
            ))}
          </div>
        </div>
      )}

      {!ready && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <div className="text-emerald-400 font-mono text-sm animate-pulse">● Loading 3D Globe…</div>
            <div className="text-muted-foreground font-mono text-[10px] mt-1">Initializing CesiumJS</div>
          </div>
        </div>
      )}
    </div>
  );
}
